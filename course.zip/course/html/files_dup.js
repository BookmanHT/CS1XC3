var files_dup =
[
    [ "course.c", "course_8c.html", "course_8c" ],
    [ "course.h", "course_8h.html", "course_8h" ],
    [ "main.c", "main_8c.html", "main_8c" ],
    [ "student.c", "student_8c.html", "student_8c" ],
    [ "student.h", "student_8h.html", "student_8h" ]
];