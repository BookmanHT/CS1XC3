var annotated_dup =
[
    [ "_course", "struct__course.html", "struct__course" ],
    [ "_student", "struct__student.html", "struct__student" ]
];